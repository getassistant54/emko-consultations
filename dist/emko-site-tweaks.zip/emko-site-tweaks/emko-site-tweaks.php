<?php
/**
 * Plugin Name: Emko Consultations & Catalog Tweaks
 * Description: Оформление карточек каталога консультаций, выравнивание страницы преподавателей, защита логотипа в шапке и встраивание виджета GetCourse.
 * Version: 1.2.0
 * Author: ЁМКО
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * 1. Глобальные стили для шапки (логотип и меню) на всех страницах сайта
 */
add_action('wp_head', function() {
    ?>
    <style id="emko-global-header-fix">
    /* Защита логотипа от сдавливания flexbox при добавлении пункта "Консультации" */
    @media (min-width: 992px) {
        .header-class {
            gap: 16px !important;
            align-items: center !important;
        }
        .header-class .logo,
        header .logo {
            flex-shrink: 0 !important;
            width: 130px !important;
            min-width: 130px !important;
            display: block !important;
        }
        .header-class .logo img,
        header .logo img {
            width: 130px !important;
            min-width: 130px !important;
            height: auto !important;
            max-width: unset !important;
            margin-top: -12px !important;
        }
        .header-class .menu__list {
            gap: 0 !important;
        }
        .header-class .menu__item {
            margin-right: 14px !important;
        }
        .header-class .menu__item a {
            font-size: 15px !important;
            white-space: nowrap !important;
        }
        .header-class .menu__item.social {
            margin-right: 14px !important;
        }
    }
    @media (max-width: 1250px) and (min-width: 992px) {
        .header-class {
            gap: 10px !important;
        }
        .header-class .menu__item {
            margin-right: 10px !important;
        }
        .header-class .menu__item a {
            font-size: 14px !important;
        }
        .header-class .logo,
        header .logo {
            width: 115px !important;
            min-width: 115px !important;
        }
        .header-class .logo img,
        header .logo img {
            width: 115px !important;
            min-width: 115px !important;
        }
        .header-class .btn--callback {
            padding: 10px 16px !important;
            font-size: 13px !important;
        }
    }
    </style>
    <?php
});

add_action('wp_footer', function() {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $is_consultations = is_page('consultations') || strpos($uri, 'consultations') !== false;
    $is_teacher = is_singular('teachers') || strpos($uri, 'teachers') !== false;

    if (!$is_consultations && !$is_teacher) {
        return;
    }
    ?>
    <style>
    .btn-frozen,
    .btn-frozen span {
        color: #ffffff !important;
        text-align: center !important;
    }
    .btn-frozen {
        cursor: pointer !important;
        opacity: 0.92 !important;
        transition: all 0.2s ease !important;
    }
    .btn-frozen:hover,
    .btn-frozen:hover span {
        color: #C90D7F !important;
        border-color: #C90D7F !important;
    }
    .btn-frozen:hover {
        background: transparent !important;
        opacity: 1 !important;
    }
    .btn-frozen:hover::before {
        opacity: 0 !important;
    }

    #callback_4 .modal__content {
        max-width: 520px !important;
        width: 100% !important;
        max-height: 94vh !important;
        overflow-y: auto !important;
        overflow-x: hidden !important;
        padding: 24px 16px 20px !important;
        border-radius: 24px !important;
        position: relative !important;
        background: #ffffff !important;
        box-shadow: 0 10px 40px rgba(0,0,0,0.15) !important;
        box-sizing: border-box !important;
    }
    #callback_4 .modal__close {
        position: absolute !important;
        top: 14px !important;
        right: 14px !important;
        z-index: 100 !important;
        cursor: pointer !important;
        background: none !important;
        border: none !important;
        padding: 4px !important;
    }
    #callback_4 .modal__title,
    #callback_4 .modal__text,
    #callback_4 form {
        display: none !important;
    }
    #emko-gc-iframe {
        width: 100% !important;
        min-height: 620px !important;
        height: 620px !important;
        border: none !important;
        display: block !important;
        background: transparent !important;
    }

    /* Выравнивание карточек преподавателей (/teachers/) В 2 КОЛОНКИ */
    .course-teachers .courses__wrapper {
        display: grid !important;
        grid-template-columns: repeat(2, 1fr) !important;
        gap: 32px !important;
        width: 100% !important;
        box-sizing: border-box !important;
    }
    @media (max-width: 900px) {
        .course-teachers .courses__wrapper {
            grid-template-columns: 1fr !important;
        }
    }
    .course-teachers .course {
        width: 100% !important;
        max-width: 100% !important;
        flex: unset !important;
        padding: 24px !important;
        display: flex !important;
        flex-direction: column !important;
        border-radius: 24px !important;
        background: #ffffff !important;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05) !important;
        box-sizing: border-box !important;
        margin: 0 !important;
        transition: transform 0.2s ease, box-shadow 0.2s ease !important;
    }
    .course-teachers .course:hover {
        transform: translateY(-3px) !important;
        box-shadow: 0 8px 30px rgba(131, 41, 139, 0.12) !important;
    }
    .course-teachers .course a {
        text-decoration: none !important;
        color: inherit !important;
        display: block !important;
        width: 100% !important;
        height: 100% !important;
    }
    .course-teachers .course__inner {
        width: 100% !important;
        height: 100% !important;
        margin: 0 !important;
    }
    .course-teachers div.dom {
        display: flex !important;
        flex-direction: row !important;
        align-items: center !important;
        gap: 24px !important;
        width: 100% !important;
        max-width: 100% !important;
        height: 100% !important;
    }
    .course-teachers .course__headd {
        width: 130px !important;
        min-width: 130px !important;
        max-width: 130px !important;
        flex-shrink: 0 !important;
        margin: 0 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        background: none !important;
    }
    .course-teachers .course__image {
        width: 130px !important;
        min-width: 130px !important;
        height: 130px !important;
        border-radius: 50% !important;
        overflow: hidden !important;
        margin: 0 !important;
        background: transparent !important;
        box-shadow: 0 4px 16px rgba(131, 41, 139, 0.12) !important;
    }
    .course-teachers img.dom,
    .course-teachers .course__image img {
        display: block !important;
        width: 130px !important;
        height: 130px !important;
        object-fit: cover !important;
        border-radius: 50% !important;
        margin: 0 auto !important;
    }
    .course-teachers .course__body {
        flex: 1 1 auto !important;
        padding: 0 !important;
        min-height: auto !important;
        max-width: 100% !important;
        display: flex !important;
        flex-direction: column !important;
        justify-content: flex-start !important;
        gap: 12px !important;
    }
    .course-teachers .course__title {
        font-size: 22px !important;
        font-weight: 700 !important;
        color: #C90D7F !important;
        line-height: 1.25 !important;
        margin: 0 !important;
    }
    .course-teachers .course__text.grey-box {
        background-color: #faf6f9 !important;
        border: 1px solid #ebdbe8 !important;
        border-radius: 16px !important;
        padding: 14px 18px !important;
        min-height: unset !important;
        height: auto !important;
        font-size: 14px !important;
        color: #4b5563 !important;
        line-height: 1.5 !important;
        position: relative !important;
    }
    .course-teachers .course__text.grey-box::before {
        content: '' !important;
        position: absolute !important;
        top: 20px !important;
        left: -14px !important;
        border-style: solid !important;
        border-width: 8px 14px 8px 0 !important;
        border-color: transparent #ebdbe8 transparent transparent !important;
        z-index: 10 !important;
    }
    .course-teachers .course__text.grey-box::after {
        content: '' !important;
        position: absolute !important;
        top: 20px !important;
        left: -12px !important;
        border-style: solid !important;
        border-width: 8px 13px 8px 0 !important;
        border-color: transparent #faf6f9 transparent transparent !important;
        z-index: 20 !important;
    }

    /* Баннер консультаций на /teachers/ */
    .emko-consult-banner {
        background: linear-gradient(135deg, #fbf2fa 0%, #f5e3f3 100%) !important;
        border: 2px solid #e5b3db !important;
        border-radius: 24px !important;
        padding: 36px 30px !important;
        margin: 10px 0 40px 0 !important;
        width: 100% !important;
        grid-column: 1 / -1 !important;
        text-align: center !important;
        box-sizing: border-box !important;
        box-shadow: 0 8px 30px rgba(131, 41, 139, 0.08) !important;
    }
    .emko-consult-banner-badge {
        display: inline-block !important;
        font-size: 12px !important;
        font-weight: 700 !important;
        letter-spacing: 1.5px !important;
        color: #ffffff !important;
        background: #83298B !important;
        padding: 5px 16px !important;
        border-radius: 20px !important;
        margin-bottom: 14px !important;
        text-transform: uppercase !important;
    }
    .emko-consult-banner h3 {
        font-size: 26px !important;
        font-weight: 800 !important;
        color: #26102a !important;
        margin: 0 0 10px 0 !important;
        line-height: 1.3 !important;
    }
    .emko-consult-banner p {
        font-size: 16px !important;
        color: #5d4661 !important;
        margin: 0 auto 22px auto !important;
        line-height: 1.5 !important;
        max-width: 700px !important;
    }
    .btn-consult-banner {
        display: inline-block !important;
        background: #C90D7F !important;
        color: #ffffff !important;
        font-size: 16px !important;
        font-weight: 700 !important;
        padding: 14px 34px !important;
        border-radius: 30px !important;
        text-decoration: none !important;
        box-shadow: 0 6px 20px rgba(201, 13, 127, 0.3) !important;
        transition: all 0.2s ease !important;
    }
    .btn-consult-banner:hover {
        background: #83298B !important;
        color: #ffffff !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 25px rgba(131, 41, 139, 0.4) !important;
    }
    </style>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var activeSlugs = ['semyon-laskin', 'dmitrij-demidov', 'kelo-lokonte'];
        var currentPath = window.location.pathname;

        // Динамическая подстройка высоты виджета по сообщению от GetCourse
        window.addEventListener('message', function(e) {
            if (e.data && e.data.height) {
                var ifr = document.getElementById('emko-gc-iframe');
                if (ifr) {
                    ifr.style.height = (parseInt(e.data.height) + 25) + 'px';
                }
            }
        }, false);

        // 1. Каталог /consultations/
        if (currentPath.indexOf('consultations') !== -1) {
            var cards = document.querySelectorAll('.courses__wrapper.consultation .course, .course');
            cards.forEach(function(card) {
                var links = card.querySelectorAll('a[href*="/teachers/"]');
                var isLive = false;
                links.forEach(function(l) {
                    var href = l.getAttribute('href') || '';
                    activeSlugs.forEach(function(slug) {
                        if (href.indexOf(slug) !== -1) isLive = true;
                    });
                });

                var bookBtn = card.querySelector('a.btn:not(.btn-grey)');
                var reviewBtn = card.querySelector('a.btn-grey');

                if (isLive) {
                    var priceBlock = card.querySelector('.course__price-value');
                    if (priceBlock) priceBlock.innerText = '4 900 ₽';
                } else if (bookBtn) {
                    bookBtn.classList.add('btn-frozen');
                    var span = bookBtn.querySelector('span');
                    if (span) span.innerText = 'Расписание уточняется';
                    else bookBtn.innerText = 'Расписание уточняется';

                    bookBtn.removeAttribute('target');
                    bookBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        if (reviewBtn && reviewBtn.getAttribute('href')) {
                            window.location.href = reviewBtn.getAttribute('href');
                        }
                    });
                }
            });
        }

        // 2. Страница преподавателя /teachers/{slug}/
        if (currentPath.indexOf('/teachers/') !== -1) {
            var isLiveTeacher = false;
            var currentTeacherSlug = '';
            activeSlugs.forEach(function(slug) {
                if (currentPath.indexOf(slug) !== -1) {
                    isLiveTeacher = true;
                    currentTeacherSlug = slug;
                }
            });

            var consultPrice = document.querySelector('.consult-teacher-desc-price');
            var consultBtn = document.querySelector('.button-buy-consult');
            var modal = document.getElementById('callback_4');

            if (isLiveTeacher) {
                if (consultPrice) consultPrice.innerText = '4900 р/час';

                if (modal && !document.getElementById('emko-gc-iframe')) {
                    var iframe = document.createElement('iframe');
                    iframe.id = 'emko-gc-iframe';
                    iframe.src = 'https://course.emko.academy/pl/lite/widget/widget?id=1628250';
                    iframe.setAttribute('scrolling', 'auto');
                    modal.querySelector('.modal__content').appendChild(iframe);
                }

                if (consultBtn) {
                    consultBtn.addEventListener('click', function() {
                        document.cookie = 'emko_order_type=consultation; domain=.emko.academy; path=/; max-age=86400';
                        document.cookie = 'emko_teacher_slug=' + currentTeacherSlug + '; domain=.emko.academy; path=/; max-age=86400';
                        try {
                            localStorage.setItem('emko_order_type', 'consultation');
                            localStorage.setItem('emko_teacher_slug', currentTeacherSlug);
                        } catch(e) {}
                    });
                }
            } else if (consultBtn) {
                consultBtn.classList.add('btn-frozen');
                consultBtn.innerText = 'Расписание уточняется';
                consultBtn.removeAttribute('data-modal');
                consultBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                });
            }
        }

        // 3. Каталог всех преподавателей /teachers/
        var isTeachersArchive = currentPath.replace(/\/$/, '') === '/teachers';
        if (isTeachersArchive) {
            var wrapper = document.querySelector('.course-teachers .courses__wrapper');
            if (wrapper && !document.querySelector('.emko-consult-banner')) {
                var banner = document.createElement('div');
                banner.className = 'emko-consult-banner';
                banner.innerHTML = '<div class="emko-consult-banner-badge">ИНДИВИДУАЛЬНАЯ КОНСУЛЬТАЦИЯ</div>' +
                    '<h3>Нужен разбор проекта, портфолио или сценария?</h3>' +
                    '<p>Запишитесь на онлайн-консультацию 1-на-1 с действующими режиссёрами и ведущими аниматорами студий.</p>' +
                    '<a href="https://emko.academy/consultations/" class="btn-consult-banner">Выбрать преподавателя и время ➔</a>';
                wrapper.insertBefore(banner, wrapper.firstChild);
            }
        }
    });
    </script>
    <?php
});
