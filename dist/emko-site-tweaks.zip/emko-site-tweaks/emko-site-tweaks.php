<?php
/**
 * Plugin Name: Emko Consultations & Catalog Tweaks
 * Description: Оформление карточек каталога консультаций, выравнивание страницы преподавателей и встраивание виджета GetCourse.
 * Version: 1.1.0
 * Author: ЁМКО
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_footer', function() {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $is_consultations = is_page('consultations') || strpos($uri, 'consultations') !== false;
    $is_teacher = is_singular('teachers') || strpos($uri, 'teachers') !== false;

    if (!$is_consultations && !$is_teacher) {
        return;
    }
    ?>
    <style>
    .btn-frozen,
    .btn-frozen span {
        color: #ffffff !important;
        text-align: center !important;
    }
    .btn-frozen {
        cursor: pointer !important;
        opacity: 0.92 !important;
        transition: all 0.2s ease !important;
    }
    .btn-frozen:hover,
    .btn-frozen:hover span {
        color: #C90D7F !important;
        border-color: #C90D7F !important;
    }
    .btn-frozen:hover {
        background: transparent !important;
        opacity: 1 !important;
    }
    .btn-frozen:hover::before {
        opacity: 0 !important;
    }

    #callback_4 .modal__content {
        max-width: 520px !important;
        width: 100% !important;
        max-height: 94vh !important;
        overflow-y: auto !important;
        overflow-x: hidden !important;
        padding: 24px 16px 20px !important;
        border-radius: 24px !important;
        position: relative !important;
        background: #ffffff !important;
        box-shadow: 0 10px 40px rgba(0,0,0,0.15) !important;
        box-sizing: border-box !important;
    }
    #callback_4 .modal__close {
        position: absolute !important;
        top: 14px !important;
        right: 14px !important;
        z-index: 100 !important;
        cursor: pointer !important;
        background: none !important;
        border: none !important;
        padding: 4px !important;
    }
    #callback_4 .modal__title,
    #callback_4 .modal__text,
    #callback_4 form {
        display: none !important;
    }
    #emko-gc-iframe {
        width: 100% !important;
        min-height: 620px !important;
        height: 620px !important;
        border: none !important;
        display: block !important;
        background: transparent !important;
    }

    /* Выравнивание сетки карточек преподавателей (/teachers/) */
    .course-teachers .courses__wrapper {
        display: grid !important;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)) !important;
        gap: 30px !important;
        width: 100% !important;
        box-sizing: border-box !important;
    }
    .course-teachers .course {
        width: 100% !important;
        max-width: 100% !important;
        flex: unset !important;
        padding: 24px !important;
        display: flex !important;
        flex-direction: column !important;
        border-radius: 24px !important;
        box-sizing: border-box !important;
        margin: 0 !important;
    }
    .course-teachers .course__inner {
        width: 100% !important;
        margin: 0 !important;
    }
    .course-teachers .dom {
        display: flex !important;
        flex-direction: row !important;
        align-items: flex-start !important;
        gap: 20px !important;
        max-width: 100% !important;
    }
    .course-teachers .course__headd {
        width: auto !important;
        flex-shrink: 0 !important;
    }
    .course-teachers .course__image {
        width: 130px !important;
        height: 180px !important;
        border-radius: 16px !important;
        overflow: hidden !important;
    }
    .course-teachers .course__image img {
        width: 100% !important;
        height: 100% !important;
        object-fit: cover !important;
    }
    .course-teachers .course__body {
        max-width: 100% !important;
        padding: 0 !important;
        min-height: auto !important;
        flex-grow: 1 !important;
    }
    .course-teachers .course__title {
        font-size: 20px !important;
        line-height: 1.3 !important;
        margin-bottom: 8px !important;
    }
    .course-teachers .course__text {
        font-size: 14px !important;
        line-height: 1.4 !important;
    }

    /* Баннер консультаций на /teachers/ */
    .emko-consult-banner {
        background: linear-gradient(135deg, rgba(131,41,139,0.2) 0%, rgba(201,13,127,0.15) 100%) !important;
        border: 1px solid rgba(201,13,127,0.35) !important;
        border-radius: 24px !important;
        padding: 28px 24px !important;
        margin: 0 0 30px 0 !important;
        width: 100% !important;
        grid-column: 1 / -1 !important;
        text-align: center !important;
        box-sizing: border-box !important;
        backdrop-filter: blur(8px) !important;
    }
    .emko-consult-banner-badge {
        display: inline-block !important;
        font-size: 11px !important;
        font-weight: 700 !important;
        letter-spacing: 1.5px !important;
        color: #C90D7F !important;
        background: rgba(201,13,127,0.12) !important;
        padding: 4px 14px !important;
        border-radius: 20px !important;
        margin-bottom: 12px !important;
    }
    .emko-consult-banner h3 {
        font-size: 24px !important;
        font-weight: 700 !important;
        color: #ffffff !important;
        margin: 0 0 8px 0 !important;
    }
    .emko-consult-banner p {
        font-size: 15px !important;
        color: #d1d5db !important;
        margin: 0 0 20px 0 !important;
    }
    .btn-consult-banner {
        display: inline-block !important;
        background: #83298B !important;
        color: #ffffff !important;
        font-weight: 600 !important;
        padding: 12px 28px !important;
        border-radius: 30px !important;
        text-decoration: none !important;
        transition: 0.2s ease !important;
    }
    .btn-consult-banner:hover {
        background: #C90D7F !important;
        transform: translateY(-2px) !important;
    }
    </style>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var activeSlugs = ['semyon-laskin', 'dmitrij-demidov', 'kelo-lokonte'];
        var currentPath = window.location.pathname;

        // Динамическая подстройка высоты виджета по сообщению от GetCourse
        window.addEventListener('message', function(e) {
            if (e.data && e.data.height) {
                var ifr = document.getElementById('emko-gc-iframe');
                if (ifr) {
                    ifr.style.height = (parseInt(e.data.height) + 25) + 'px';
                }
            }
        }, false);

        // 1. Каталог /consultations/
        if (currentPath.indexOf('consultations') !== -1) {
            var cards = document.querySelectorAll('.courses__wrapper.consultation .course, .course');
            cards.forEach(function(card) {
                var links = card.querySelectorAll('a[href*="/teachers/"]');
                var isLive = false;
                links.forEach(function(l) {
                    var href = l.getAttribute('href') || '';
                    activeSlugs.forEach(function(slug) {
                        if (href.indexOf(slug) !== -1) isLive = true;
                    });
                });

                var bookBtn = card.querySelector('a.btn:not(.btn-grey)');
                var reviewBtn = card.querySelector('a.btn-grey');

                if (isLive) {
                    var priceBlock = card.querySelector('.course__price-value');
                    if (priceBlock) priceBlock.innerText = '4 900 ₽';
                } else if (bookBtn) {
                    bookBtn.classList.add('btn-frozen');
                    var span = bookBtn.querySelector('span');
                    if (span) span.innerText = 'Расписание уточняется';
                    else bookBtn.innerText = 'Расписание уточняется';

                    bookBtn.removeAttribute('target');
                    bookBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        if (reviewBtn && reviewBtn.getAttribute('href')) {
                            window.location.href = reviewBtn.getAttribute('href');
                        }
                    });
                }
            });
        }

        // 2. Страница преподавателя /teachers/{slug}/
        if (currentPath.indexOf('/teachers/') !== -1) {
            var isLiveTeacher = false;
            var currentTeacherSlug = '';
            activeSlugs.forEach(function(slug) {
                if (currentPath.indexOf(slug) !== -1) {
                    isLiveTeacher = true;
                    currentTeacherSlug = slug;
                }
            });

            var consultPrice = document.querySelector('.consult-teacher-desc-price');
            var consultBtn = document.querySelector('.button-buy-consult');
            var modal = document.getElementById('callback_4');

            if (isLiveTeacher) {
                if (consultPrice) consultPrice.innerText = '4900 р/час';

                if (modal && !document.getElementById('emko-gc-iframe')) {
                    var iframe = document.createElement('iframe');
                    iframe.id = 'emko-gc-iframe';
                    iframe.src = 'https://course.emko.academy/pl/lite/widget/widget?id=1628250';
                    iframe.setAttribute('scrolling', 'auto');
                    modal.querySelector('.modal__content').appendChild(iframe);
                }

                if (consultBtn) {
                    consultBtn.addEventListener('click', function() {
                        document.cookie = 'emko_order_type=consultation; domain=.emko.academy; path=/; max-age=86400';
                        document.cookie = 'emko_teacher_slug=' + currentTeacherSlug + '; domain=.emko.academy; path=/; max-age=86400';
                        try {
                            localStorage.setItem('emko_order_type', 'consultation');
                            localStorage.setItem('emko_teacher_slug', currentTeacherSlug);
                        } catch(e) {}
                    });
                }
            } else if (consultBtn) {
                consultBtn.classList.add('btn-frozen');
                consultBtn.innerText = 'Расписание уточняется';
                consultBtn.removeAttribute('data-modal');
                consultBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                });
            }
        }

        // 3. Каталог всех преподавателей /teachers/
        var isTeachersArchive = currentPath.replace(/\/$/, '') === '/teachers';
        if (isTeachersArchive) {
            var wrapper = document.querySelector('.course-teachers .courses__wrapper');
            if (wrapper && !document.querySelector('.emko-consult-banner')) {
                var banner = document.createElement('div');
                banner.className = 'emko-consult-banner';
                banner.innerHTML = '<div class="emko-consult-banner-badge">ИНДИВИДУАЛЬНОЕ ОБУЧЕНИЕ</div>' +
                    '<h3>Нужен разбор проекта, портфолио или сценария?</h3>' +
                    '<p>Запишитесь на онлайн-консультацию 1-на-1 с действующими режиссёрами и ведущими аниматорами студий.</p>' +
                    '<a href="https://emko.academy/consultations/" class="btn-consult-banner">Выбрать преподавателя и время ➔</a>';
                wrapper.insertBefore(banner, wrapper.firstChild);
            }
        }
    });
    </script>
    <?php
});
