<?php
/**
 * Plugin Name: Emko Consultations & Catalog Tweaks
 * Description: Оформление карточек каталога консультаций и встраивание виджета оплаты GetCourse в модальное окно преподавателей.
 * Version: 1.0.0
 * Author: ЁМКО
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_footer', function() {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $is_consultations = is_page('consultations') || strpos($uri, 'consultations') !== false;
    $is_teacher = is_singular('teachers') || strpos($uri, '/teachers/') !== false;

    if (!$is_consultations && !$is_teacher) {
        return;
    }
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var activeSlugs = ['semyon-laskin', 'dmitrij-demidov', 'kelo-lokonte'];
        var currentPath = window.location.pathname;

        // Динамическая подстройка высоты виджета по сообщению от GetCourse
        window.addEventListener('message', function(e) {
            if (e.data && e.data.height) {
                var ifr = document.getElementById('emko-gc-iframe');
                if (ifr) {
                    ifr.style.height = (parseInt(e.data.height) + 25) + 'px';
                }
            }
        }, false);

        // 1. Каталог /consultations/
        if (currentPath.indexOf('consultations') !== -1) {
            var cards = document.querySelectorAll('.courses__wrapper.consultation .course, .course');
            cards.forEach(function(card) {
                var links = card.querySelectorAll('a[href*="/teachers/"]');
                var isLive = false;
                links.forEach(function(l) {
                    var href = l.getAttribute('href') || '';
                    activeSlugs.forEach(function(slug) {
                        if (href.indexOf(slug) !== -1) isLive = true;
                    });
                });

                var bookBtn = card.querySelector('a.btn:not(.btn-grey)');
                var reviewBtn = card.querySelector('a.btn-grey');

                if (isLive) {
                    var priceBlock = card.querySelector('.course__price-value');
                    if (priceBlock) priceBlock.innerText = '4 900 ₽';
                } else if (bookBtn) {
                    bookBtn.classList.add('btn-frozen');
                    var span = bookBtn.querySelector('span');
                    if (span) span.innerText = 'Расписание уточняется';
                    else bookBtn.innerText = 'Расписание уточняется';

                    bookBtn.removeAttribute('target');
                    bookBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        if (reviewBtn && reviewBtn.getAttribute('href')) {
                            window.location.href = reviewBtn.getAttribute('href');
                        }
                    });
                }
            });
        }

        // 2. Страница преподавателя /teachers/{slug}/
        if (currentPath.indexOf('/teachers/') !== -1) {
            var isLiveTeacher = false;
            var currentTeacherSlug = '';
            activeSlugs.forEach(function(slug) {
                if (currentPath.indexOf(slug) !== -1) {
                    isLiveTeacher = true;
                    currentTeacherSlug = slug;
                }
            });

            var consultPrice = document.querySelector('.consult-teacher-desc-price');
            var consultBtn = document.querySelector('.button-buy-consult');
            var modal = document.getElementById('callback_4');

            if (isLiveTeacher) {
                if (consultPrice) consultPrice.innerText = '4900 р/час';

                if (modal && !document.getElementById('emko-gc-iframe')) {
                    var iframe = document.createElement('iframe');
                    iframe.id = 'emko-gc-iframe';
                    iframe.src = 'https://course.emko.academy/pl/lite/widget/widget?id=1628250';
                    iframe.setAttribute('scrolling', 'auto');
                    modal.querySelector('.modal__content').appendChild(iframe);
                }

                if (consultBtn) {
                    consultBtn.addEventListener('click', function() {
                        document.cookie = 'emko_order_type=consultation; domain=.emko.academy; path=/; max-age=86400';
                        document.cookie = 'emko_teacher_slug=' + currentTeacherSlug + '; domain=.emko.academy; path=/; max-age=86400';
                        try {
                            localStorage.setItem('emko_order_type', 'consultation');
                            localStorage.setItem('emko_teacher_slug', currentTeacherSlug);
                        } catch(e) {}
                    });
                }
            } else if (consultBtn) {
                consultBtn.classList.add('btn-frozen');
                consultBtn.innerText = 'Расписание уточняется';
                consultBtn.removeAttribute('data-modal');
                consultBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                });
            }
        }
    });
    </script>
    <?php
});
